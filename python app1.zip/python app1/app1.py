from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox


class Todo:
    def __init__(self, root):
        self.root = root
        self.root.title("To Do List")
        self.root.geometry('650x550+300+150')  # Size Of The GUI
        self.root.resizable(False, False)

        # Load a JPEG image using Pillow and resize it
        image = Image.open('image/Capture.png')  # Ensure this path is correct
        self.photo = ImageTk.PhotoImage(image)
        self.image_label = Label(self.root, image=self.photo)
        self.image_label.pack(side='top')  # Pack image at the top

        # Labels for title and task input below the image
        self.label1 = Label(self.root, text='To-Do-List-Internship', font='calibri 20 bold', bd=5, bg='Navy', fg='white')
        self.label1.pack(side='top', fill='x')  # Pack title below the image

        self.label2 = Label(self.root, text='Create Task', font='calibri 15 bold', bd=5, bg='Red', fg='white')
        self.label2.pack(side='top', pady=10)
        self.label2.place(x=100, y=130)  # Task label just below the title

        self.label3 = Label(self.root, text='Tasks', font='calibri 15 bold', bd=5, bg='Navy', fg='white')
        self.label3.pack(side='top', pady=10)
        self.label3.place(x=485, y=130)  # Task label just below the title

        self.box = Listbox(self.root, height=12, bd=5, width=26, font='calibri 12 bold')
        self.box.place(x=400, y=170)

        self.text = Text(self.root, height=2, bd=5, width=26, font='calibri 12 bold')
        self.text.place(x=45, y=170)

        # Category Selection
        self.category_var = StringVar()
        self.category_var.set("General")
        self.categories = ['General', 'Work', 'Home', 'Personal']
        self.category_menu = OptionMenu(self.root, self.category_var, *self.categories)
        self.category_menu.config(font='calibri 12 bold', width=9, bd=3, bg='red', fg='white')
        self.category_menu.place(x=210, y=305)

        # Search Bar
        self.search_var = StringVar()
        self.search_bar = Entry(self.root, textvariable=self.search_var, font='calibri 12 bold', width=20, bd=5)
        self.search_bar.place(x=70, y=375)

        #Delete Function
        def delete():
            delete = self.box.curselection()
            if delete:
                self.box.delete(delete)


        #Search Tasks
        def SearchTasks():
            search_query = self.search_var.get().lower()
            tasks = self.box.get(0, END)
            self.box.delete(0, END)
            for task in tasks:
                if search_query in task.lower():
                    self.box.insert(END, task)


        #Filter
        def FilterTasks():
         filter_query = self.category_var.get()
         tasks = self.box.get(0, END)
         self.box.delete(0, END)
         for task in tasks:
          if f",{filter_query}]" in task:  # Adjusted to match the format in combined task
            self.box.insert(END, task)
        
        #Status
        self.status_var = StringVar()
        self.status_var.set("Pending")
        self.statuses = ['Pending', 'In Progress', 'Completed']
        self.status_menu = OptionMenu(self.root, self.status_var, *self.statuses)
        self.status_menu.config(font='calibri 12 bold', width=9, bd=3, bg='red', fg='white')
        self.status_menu.place(x=70, y=305)

        def add():
         content = self.text.get(1.0, END).strip()
         if content:
        # Combine The content with status and category
          CombinedTask = f"{content} [{self.status_var.get()},{self.category_var.get()}]"
        # Check for duplicates
         if CombinedTask in self.box.get(0, END):
            # show alert if dupicated
           messagebox.showerror("Duplicated Task", "Task is already in the list")
         else:
            # If not a duplicate, add to the list and file
            self.box.insert(END, CombinedTask)
            with open('MyData.txt', 'a') as file:
                file.write(CombinedTask + '\n')
            self.text.delete(1.0, END)

        #Updating the Status of the content
        def UpdateStatus():
            selected = self.box.curselection()
            if selected:
                current_content = self.box.get(selected[0]).split(' [')[0]
                updated_task = f"{current_content} [{self.status_var.get()}]"
                self.box.delete(selected[0])
                self.box.insert(selected[0], updated_task)
                # Update the file storage as well
                tasks = self.box.get(0, END)
                with open('MyData.txt', 'w') as file:
                    for task in tasks:
                        file.write(task + '\n')

        

        self.button1 = Button(self.root, text='ADD', font='calibri 15 bold', width=8, bd=3, bg='red', fg='white', command=add)
        self.button1.place(x=280, y=170)#ADD Task Button

        self.button2 = Button(self.root, text='Delete', font='calibri 15 bold', width=8, bd=3, bg='navy', fg='white', command=delete)
        self.button2.place(x=165, y=240) #Delete Button

        self.button3 = Button(self.root, text='Search', font='calibri 15 bold', width=8, bd=3, bg='red', fg='white', command=SearchTasks)
        self.button3.place(x=250, y=370) #Search Button

        self.button4 = Button(self.root, text='Filter', font='calibri 15 bold', width=8, bd=3, bg='blue', fg='white', command=FilterTasks)
        self.button4.place(x=50, y=240)  # Filter button

        self.label4 = Label(self.root, text='Done By Abdallah Kaadan', font='calibri 20 bold', bd=5, bg='red', fg='white')
        self.label4.pack(side='bottom', fill='x') #Done Abdallah Kaadan

        self.button6 = Button(self.root, text='Status', font='calibri 15 bold', width=8, bd=3, bg='blue', fg='white', command=UpdateStatus)
        self.button6.place(x=280, y=240)#Status Button




def main():
    root = Tk()
    ui = Todo(root)
    root.mainloop()

if __name__ == "__main__":
    main()
